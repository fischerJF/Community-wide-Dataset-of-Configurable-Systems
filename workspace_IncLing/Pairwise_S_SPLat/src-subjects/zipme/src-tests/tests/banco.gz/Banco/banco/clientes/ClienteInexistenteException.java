package clientes;

/**
 * Exce��o lan�ada quando um cliente n�o existe no cadastro de clientes.
 *
 * @author empresa <a href="mailto:empresa@com.br">empresa@com.br</a>
 *
 * @version 1.0
 *
 * @see banco.cliente.RepositorioClientes
 */
@SuppressWarnings("serial")
public class ClienteInexistenteException extends Exception {

	/**
	 * O CPF do cliente n�o existente no cadastro.
	 */
	private String cpf;

	/**
	 * O construtor da classe. Inicializa a mensagem da super-classe com uma mensagem
	 * padr�o de cliente n�o cadastrado e inicializa o cpf cujo cliente n�o existe no cadastro.
	 *
	 * @param cpf o CPF do cliente n�o existente no cadastro.
	 */
	public ClienteInexistenteException(String cpf) {

		super(MSG_CLI_INEXISTENTE);
		this.cpf = cpf;
	}

	/**
	 * Retorna o CPF do cliente n�o existente no cadastro.
	 *
	 * @return String o CPF do cliente n�o existente no cadastro.
	 */
	public String getCpf() {

		return cpf;
	}
	/**
	 * Constante com a mensagem de cliente n�o cadastrado.
	 */
	private static final String MSG_CLI_INEXISTENTE =
		"Cliente n�o cadastrado !!";
}