package clientes;

/**
 * Exce��o lan�ada quando um cliente � nulo em uma opera��o de cadastro de contas.
 *
 * @author empresa <a href="mailto:empresa@com.br">empresa@com.br</a>
 *
 * @version 1.0
 *
 * @see banco.fachada.Fachada
 */
@SuppressWarnings("serial")
public class ClienteInvalidoException extends Exception {
}
