package fachada;


import fachada.Fachada;
import clientes.Cliente;
import contas.Conta;
import contas.ContaAbstrata;
import contas.Poupanca;

/**
 * Classe de teste para os metodos da fachada 
 * 
 * @author empresa <a href="mailto:empresa@com.br">empresa@com.br</a>
 *
 * @version 1.0 
 *
 * @sebanco.fachada.e Fachada
 * 
 */
public class TesteFachada {

	public static void main(String[] args) {
		Fachada fachada = Fachada.obterInstancia();

		Cliente c = new Cliente("11", "Jo�o");
		ContaAbstrata c1 = new Conta("1", 100, c);
		ContaAbstrata c2 = new Poupanca("2", 10, c);

		try {

			fachada.cadastrar(c);
			fachada.cadastrar(c1);
			fachada.cadastrar(c2);
			Cliente cli1 = fachada.procurarCliente("11");
			System.out.println("Nome do cliente: " + cli1.getNome());

			ContaAbstrata con1 = fachada.procurarConta("1");
			System.out.println("Saldo da conta de n�mero " + con1.getNumero()
					+ ": " + con1.getSaldo());

			fachada.creditar("2", 300);
			ContaAbstrata con2 = fachada.procurarConta("2");
			((Poupanca) con2).renderJuros(0.008);
			System.out.println("Saldo da conta de n�mero " + con2.getNumero()
					+ ": " + con2.getSaldo());

			con2.debitar(1000);
			fachada.atualizar(con2);
			con2 = fachada.procurarConta("2");
			System.out.println("Saldo atualizado da conta de n�mero "
					+ con2.getNumero() + ": " + con2.getSaldo());

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
